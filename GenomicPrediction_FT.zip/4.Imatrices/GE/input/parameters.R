


G1.file <- '../../../3.Gmatrices/G/output/G.rda'          # path to matrix file 1
G2.file <- '../../../3.Gmatrices/E/output/G.rda'          # path to matrix file 2

 