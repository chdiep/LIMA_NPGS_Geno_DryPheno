phenotype.file   <- '../../../../5.1.CV2.CV1/rep_5/output/Y.csv' 
 folds <-  5 
 colPhen <- 3
 colFolds <- 8
