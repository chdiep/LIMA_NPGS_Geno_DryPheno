

rm(list=ls())

 setwd('../output')

 source('../input/parameters.R')

## Reads phenotype file ####################################
 Y <- read.table(phenotype.file,sep=',', header=TRUE, stringsAsFactors=FALSE )
## Reads environmental covariates ##########################
 

     TF <- matrix(NA,nrow=dim(Y),ncol=folds)
     colnames(TF) <- paste('fold_',1:5,sep='')
     TF[,] <- Y[,colPhen] 

     for(fold in 1:folds)
       {

         TF[Y[,colFolds]==fold,fold] <- NA
         print(fold)
       }
     Y2 <- cbind(Y,TF)
     write.csv(Y2,file='Y.csv',row.names=FALSE)


quit(save='no')