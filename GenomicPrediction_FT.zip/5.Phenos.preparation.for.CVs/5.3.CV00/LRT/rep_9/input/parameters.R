phenotype.file   <- '../../../../5.1.CV2.CV1/rep_9/output/Y.csv' 
 folds <-  5 
 colPhen <- 5
 colFolds <- 7
