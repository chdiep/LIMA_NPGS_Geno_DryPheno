phenotype.file   <- '../../../../5.1.CV2.CV1/rep_2/output/Y.csv' 
 folds <-  5 
 colPhen <- 4
 colFolds <- 7
