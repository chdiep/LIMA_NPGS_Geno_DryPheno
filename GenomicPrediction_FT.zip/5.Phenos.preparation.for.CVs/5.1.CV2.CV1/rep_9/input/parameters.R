phenotype.file   <- '../../../../1.root.Data/YS.csv' 
 folds <-  5 
 colIDy <- 1 
 CV1 <- TRUE 
 CV2 <- TRUE 
set.seed(9)
