

rm(list=ls())

 setwd('../output')

 source('../input/parameters.R')

## Reads phenotype file ####################################
 Y <- read.table(phenotype.file,sep=',', header=TRUE, stringsAsFactors=FALSE )
## Reads environmental covariates ##########################
 


 IDs<-unique(Y[,colIDy])

## Assigns lines to folds (CV1) ###########################


length(IDs)

 fold <- rep(1:folds,each=ceiling(length(IDs)/folds))[order(runif(length(IDs)))]

 if(CV1)
  {
   Y$CV1 <- NA
   for(i in 1:folds)
     {
       tmp<-Y[,colIDy]%in%IDs[fold==i]
       Y$CV1[tmp]<-i
     }
   }
## Assigns cells to folds (CV2) ###########################
 
 if(CV2)
  {
   Y$CV2 <- NA

   for(i in IDs)
     {
       tmp<-which(Y[,colIDy]==i)
       ni<-length(tmp)
       fold<-sample(1:folds,size=ni,replace=length(tmp)>folds)
       Y$CV2[tmp]<-fold
       print(table(fold))
     }
  }
	
write.table(Y, file='Y.csv', sep=',', row.names=F, col.names=T)

quit(save='no')