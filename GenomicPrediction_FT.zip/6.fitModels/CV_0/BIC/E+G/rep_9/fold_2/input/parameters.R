 folds   <-  1 : 2
 nIter  <- 12000
 burnIn <- 2000
phenotype.file <- '../../../../../../../5.Phenos.preparation.for.CVs/5.2.CV0/BIC/rep_9/output/Y.csv' 
 AB <- list() 
 AB[[1]] <- '../../../../../../../3.Gmatrices/E/output/EVD.rda'   
 AB[[2]] <- '../../../../../../../3.Gmatrices/G/output/EVD.rda'   
 type <- c('RKHS','RKHS','RKHS','RKHS') 
 colENV  <- NULL  # column in phenotype file that gives the id of the environment 
 colVAR  <- 1  # column in phenotype file that gives the id of the variety 
 colPhen <- 10
 colCV <- 6
 CV0 <- FALSE
 ESC <- FALSE 
 set.seed(9)
