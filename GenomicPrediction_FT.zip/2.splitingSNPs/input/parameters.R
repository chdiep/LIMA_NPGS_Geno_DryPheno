mm.file <- '../../1.root.Data/SNPs.rda' # path to covariate file
NaN.freq.i <-  127*0.2 # number of missing values by SNPs
