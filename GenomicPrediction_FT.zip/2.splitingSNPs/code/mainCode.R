


  setwd('../output')

  source('../input/parameters.R')

  load(mm.file)

  NaNs <- matrix(NA,nrow=1, ncol=dim(SNPs)[2])
  for(i in 1:dim(SNPs)[2])
   {
   NaNs[i] <- length(which(is.na(SNPs[,i])))
   }

   index.1 <- order(NaNs) 
   NaNs2 <- NaNs[index.1]

   

   NaN.freq <- unique(NaNs2)   
   percentage.NaNs <- NaN.freq * 100 / dim(SNPs)[1]


   write.table(NaN.freq, file='NaNs.freq.csv', sep=',',row.names=F, col.names=F)
   write.table(percentage.NaNs, file='percentage.NaNs.csv', sep=',',row.names=F, col.names=F)
  


    index.2 <- which(NaNs <= NaN.freq.i)
    X <- SNPs[,index.2]

    write.csv(X, file='X.csv')

quit(save='no')








